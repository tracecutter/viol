#!/usr/bin/python

import simplejson as json
import csv
import sys
import time
import datetime
from evrythng import * 
import environments # Gets the variables

# 0 for displaying all data, 1 only for critical stuff, 2 for warning & errors, 3 for errors only
setLogLevel(1)


# Configure Server Connex
setDomain(environments.ihprod['domain'])
setOperator(environments.ihprod['operatorApiKey'])


# Set the start & end date
startTime=int(datetime.datetime.strptime('27/10/2015', '%d/%m/%Y').strftime("%s"))*1000
endTime=int(datetime.datetime.strptime('28/10/2015', '%d/%m/%Y').strftime("%s"))*1000

results=list()

# Get the total number of results
[response,end] = headThngs('UWCC5rmCsVpwPsCnWeSsDrMe')
headers = dict(response['headers'])
total = int(headers['x-result-count'])

# Now Get all Thngs (with pagination)
page = 1 
#while page < 3:
while len(results) < total:
	[response,end] = getAllThngs('UWCC5rmCsVpwPsCnWeSsDrMe',page)
	print "Loaded page "+str(page)+" (total retireved "+str(len(results))+" / "+str(total)+" )"
	page = page + 1
	results.extend(json.loads(str(response['body'])))


# Thngs is now a list of objects, we can sort it and filter it and do whatever
thngs=sorted(results, key=lambda k: k['createdAt']) 


with open('output.csv', 'w') as csvfile:
    fieldnames = ['id','createdAt','homekitid','owner']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Let's loop over all thngs
    for thng in thngs:
		#logging.info("Thng ID #%s (%d - %s)\n",thng["id"],thng["createdAt"], time.strftime("%d/%m/%Y", time.localtime(thng["createdAt"]/1000)))
		if (startTime <= int(thng["createdAt"]) <= endTime):
			t={}
			t['id']=thng["id"]
			t['createdAt']=time.strftime("%d/%m/%Y", time.localtime(thng["createdAt"]/1000))
			t['homekitid']=thng["identifiers"]["homekitid"] if 'homekitid' in thng['identifiers'].keys() else "null"
			t['owner']=thng["identifiers"]["owner"] if 'owner' in thng['identifiers'].keys() else "null"
			print thng["id"]+", "+time.strftime("%d/%m/%Y", time.localtime(thng["createdAt"]/1000))+", "+thng["identifiers"]["homekitid"]+", "+thng["identifiers"]["owner"]+" "
			writer.writerow({'id':t['id'],'createdAt':t['createdAt'],'homekitid':t['homekitid'],'owner':t['owner']})

print "done"

