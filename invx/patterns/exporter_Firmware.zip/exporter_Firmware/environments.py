#!/usr/bin/python


teststaging = {'domain': 'api-staging.evrythng.net', 'operatorApiKey':'LomVdE6w0HG6udp4JXADY3ROm75i7hRevNrZSJF3d4PChLeWfdoQTUQlIMUrF9wzskkbDfdhdQfyWdyA','appApiKey': 'NjqPlJcLiqk2icFIzSIgXa8J0W6ixq14IyeIgbTEj5LwoIFYCARnHKaJ2dVA47dRWnZ0bxlSYLiwbodT','appId':'5462034385a2ddf274e0a1a3'}

vtprod = {'domain': 'api.evrythng.com', 'operatorApiKey':'','appApiKey': '','appId':''}

ihprod = {'domain': 'api.evrythng.com', 'operatorApiKey':'lMlOO4L5ufqgJVjoQNclS9aVExJGdUE1Yj91ge3caSM1hXK8g62SBdrJg40YDdr2a0TdcD4gozKdKrR7','appApiKey': '','appId':''}

vttest = {'domain': 'api-test.evrythng.net', 'operatorApiKey':'GljBtwtnjJkWxJs3n54EsijmnFkU8xpYQk1xzAYiExFLVaQiFXPreUHtuLZ3l8xSVfBjNm1FR8QNDLlp','appApiKey': '','appId':''}

vtstaging = {'domain': 'api-staging.evrythng.net', 'operatorApiKey':'G3fbwuuxFT9cAPzPiF6pdzYS8R0Qyu9wzlXlWah80Y8EIWogCWzXOh2n7G8eI8s8veXuDfslBH1ibzC0','appApiKey': '','appId':''}

masterstaging = {'domain': 'api-staging.evrythng.net', 'apiKey':'a3f16eb3a62f474ee1562b5c2435fe592a4f8edc'}

#myenv1 = {'domain': '', 'operatorApiKey':'','appApiKey': '','appId':''}

